ABROAD THINKERS - FREE WEBSITE

1. Open index.html in Chrome to preview the website.
2. Replace:
   - your@email.com
   - +91XXXXXXXXXX / the WhatsApp link
3. For free hosting, upload index.html to a GitHub repository and enable GitHub Pages.
4. Later, connect your own domain if desired.

The site is responsive for desktop, tablet and mobile.
